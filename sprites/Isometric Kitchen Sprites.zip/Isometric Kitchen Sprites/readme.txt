--------------------------------------------------------------------------------------------------------------
Isometric Kitchen Sprites
--------------------------------------------------------------------------------------------------------------
Over 40 isometric kitchen objects
All files are in .png format with transparency. Some objects have color variations and frames for animation.

Includes:

barstools
blender 
breadbox
cabinets
chairs
chopping boards
Food processor*
Coffee machines (drip, espresso) 
coffee pot
condiments
cookers (gas, portable, hotplates)
cooker hoods
counters
grater
refrigerators
kettle (electric, steam)
knife rack
microwave*
mini-grill*
mixer
paper towel dispenser
pestle & mortar
plate rack
plates & bowls
rice cooker
sandwich grill
saucepan rack
scales
shelves
sinks
wooden keg
spice racks
tables
toaster*

*animation frames

--------------------------------------------------------------------------------------------------------------
tags: isometric, kitchen, appliances, furniture
--------------------------------------------------------------------------------------------------------------
Made by JP Cummins

jpcummins.com
jpaulcuk@gmail.com